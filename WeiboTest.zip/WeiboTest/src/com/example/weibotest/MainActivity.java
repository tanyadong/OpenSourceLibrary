package com.example.weibotest;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import com.android.volley.Response;
import com.android.volley.Response.Listener;
import com.example.weibotest.ParseData.HttpException;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.util.Xml;
import android.view.Menu;

public class MainActivity extends Activity {

	Listener<String> mListener;
	String mCacheDir;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mCacheDir = this.getCacheDir().getPath();
		System.out.println("mCacheDir="+mCacheDir);
//		mListener = new Response.Listener<String>() {
//
//			@Override
//			public void onResponse(String message) {
//				try {
//					Object[] array = ParseData.getMBlogList(message);
//					System.out.println("====size="+array.length);
//				} catch (HttpException e) {
//					e.printStackTrace();
//				}
//			}
//		};
//		GetDataViaVolley valley = GetDataViaVolley.getInstance(this);
//		valley.setListener(mListener);
//		valley.fetchData();
		parseAssertData();
	}
	
	public void parseAssertData() {
		InputStream is = null;
		try {
			is = this.getAssets().open("11.xml", Context.MODE_PRIVATE);
			int length = is.available();
			byte[] buffer = new byte[length];
			is.read(buffer);
			String temp = new String(buffer);

			try {
				Object[] array = ParseData.getMBlogList(temp);
				List<MBlog> list = (List<MBlog>)array[1];
				FileUtils.save(list, mCacheDir+'/'+"001_fav");
				
				
				List<MBlog> list1 = (List<MBlog>)FileUtils.load(mCacheDir+'/'+"001_fav");
				MBlog blog = list1.get(1);
				System.out.println("===size="+blog.src);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	
}
