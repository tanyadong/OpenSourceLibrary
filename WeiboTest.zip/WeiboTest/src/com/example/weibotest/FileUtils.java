package com.example.weibotest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileUtils {

	//path /data/data/com.sina.weibo/cache/1316202912_favorite
	public static Object load(String path) {
		Object obj = null;
		File file = new File(path);
		try {
			/*if(file != null){
				file.mkdirs();
			}*/
			if (file.exists()) {
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);
				try {
					obj = ois.readObject();
				}
				catch (ClassNotFoundException e) {
				}
				ois.close();
			}	
		}catch (IOException e) {
			}
		return obj;
	}
	
	
	public static void save(Object obj, String path) {
		try {
			File f = new File(path);
			/*if(f != null){
				f.mkdirs();
				f.createNewFile();
			}*/
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(obj);
			oos.flush();
			oos.close();
		}
		catch (IOException e) {
		}
	}

}
