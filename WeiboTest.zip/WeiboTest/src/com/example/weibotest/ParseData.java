package com.example.weibotest;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.text.TextUtils;
import android.util.Xml;

public class ParseData {

	private static String PARSE_ERROR = "Problem parsing API response";
	
	public static Object[] getMBlogList(String content) throws HttpException {
		try {
			Object[] result = new Object[3];
			List<MBlog> lst = new ArrayList<MBlog>();
			result[1] = lst;

			final XmlPullParser parser = Xml.newPullParser();
			parser.setInput(new StringReader(content));
			int type;
			while ((type = parser.next()) != XmlPullParser.END_DOCUMENT) {
				switch (type) {
					case XmlPullParser.START_TAG:
						if (parser.getName().equals("count")) {
							try {
								result[0] = new Integer(parseText(parser));
							} catch (Exception e) {
								result[0] = 0;
							}
						} else if (parser.getName().equals("mblog")) {
							MBlog mb = parseMBlog(parser);
							if (mb != null)
								lst.add(mb);
						} else if (parser.getName().equals("relation")) {
							result[2] = new Integer(parseText(parser));
						}
						break;
					default:
						break;
				}
			}
			return result;
		} catch (NumberFormatException e) {
			throw new HttpException(e);
		} catch (XmlPullParserException e) {
			throw new HttpException(e);
		} catch (IOException e) {
			throw new HttpException(e);
		} catch (ParseException e) {
			throw new HttpException(e);
		}
	}
	
	private static String parseText(XmlPullParser parser) throws ParseException {
		try {
			int type = parser.next();
			if (type == XmlPullParser.TEXT) {
				return replaceEntityRef(parser.getText().trim());
			} else {
				return "";
			}
		} catch (Exception e) {
			throw new ParseException(PARSE_ERROR, e);
		}
	}
	
	public static MBlog parseMBlog(XmlPullParser parser) throws ParseException {
		MBlog b = new MBlog();
		try {
			int type;
			LOOP: {
				while ((type = parser.next()) != XmlPullParser.END_DOCUMENT) {
					switch (type) {
						case XmlPullParser.START_TAG:
							if (parser.getName().equals("uid")) {
								b.uid = parseText(parser);
								if (b.uid.equals(""))
									return null;
							} else if (parser.getName().equals("favid")) {
								b.favid = parseText(parser);
							} else if (parser.getName().equals("mblogid")) {
								b.mblogid = parseText(parser);
							} else if (parser.getName().equals("nick")) {
								String s = parseText(parser);
								b.nick = s;
							} else if (parser.getName().equals("portrait")) {
								b.portrait = parseText(parser);
							} else if (parser.getName().equals("vip")) {
								b.vip = (parseText(parser).equals("1")) ? true : false;
							} else if (parser.getName().equals("content")) {
								b.content = parseText(parser);
							} else if (parser.getName().equals("rtrootuid")) {
								b.rtrootuid = parseText(parser);
							} else if (parser.getName().equals("rtrootid")) {
								b.rtrootid = parseText(parser);
							} else if (parser.getName().equals("rtrootnick")) {
								String s = parseText(parser);
								b.rtrootnick = s;
							} else if (parser.getName().equals("rtrootvip")) {
								b.rtrootvip = (parseText(parser).equals("1")) ? true : false;
							} else if (parser.getName().equals("rtreason")) {
								b.rtreason = parseText(parser);
							} else if (parser.getName().equals("rtnum")) {
								b.rtnum = Integer.parseInt(parseText(parser));
							} else if (parser.getName().equals("commentnum")) {
								b.commentnum = Integer.parseInt(parseText(parser));
							} else if (parser.getName().equals("time")) {
								b.time = new Date(Long.parseLong(parseText(parser)) * 1000);
							} else if (parser.getName().equals("pic")) {
								b.pic = parseText(parser);
							} else if (parser.getName().equals("source")) {
								b.src = parseText(parser);
							} else if (parser.getName().equals("longitude")) {
								b.longitude = parseText(parser);
							} else if (parser.getName().equals("latitude")) {
								b.latitude = parseText(parser);
							}
							break;
						case XmlPullParser.END_TAG:
							if (parser.getName().equals("mblog")) {
								break LOOP;
							}
							break;
						default:
							break;
					}
				}
			}
			return b;
		} catch (Exception e) {
			throw new ParseException(PARSE_ERROR, e);
		}
	}
	
	private static String replaceEntityRef(String src) {
		// String out = src.replaceAll("&lt;", "<");
		// out = out.replaceAll("&gt;", ">");
		// out = out.replaceAll("&amp;", "&");
		// out = out.replaceAll("&apos;", "'");
		// out = out.replaceAll("&quot;", "\"");
		// return out;
		return replaceEntityRef2(src);
	}
	private static final Pattern entryPattern = Pattern.compile("&\\w+;");
	private static final HashMap<String, String> ENTRY_MAP = new HashMap<String, String>();
	
	private static String replaceEntityRef2(String src) {
		Matcher m = entryPattern.matcher(src);
		StringBuilder buffer = new StringBuilder();
		int start = -1, end = -1, lastEnd = -1;
		String val = null;
		while (m.find()) {
			start = m.start();
			end = m.end();
			val = ENTRY_MAP.get(m.group());
			if (!TextUtils.isEmpty(val)) {
				if (lastEnd != -1) {
					buffer.append(src.substring(lastEnd, start));
					buffer.append(val);
					lastEnd = end;
					start = -1;
					end = -1;
				}
			}
		}
		if (lastEnd == -1) {
			return src;
		} else if (lastEnd != src.length()) {
			buffer.append(src.substring(lastEnd));
		}

		return buffer.toString();
	}

	public static class HttpException extends Exception {
		private static final long serialVersionUID = 5672654600892372211L;

		private int statusCode = -1;

		public int getStatusCode() {
			return statusCode;
		}

		public void setStatusCode(int statusCode) {
			this.statusCode = statusCode;
		}

		public HttpException() {
			super();
		}

		public HttpException(int statusCode) {
			super();
			this.statusCode = statusCode;
		}

		public HttpException(String detailMessage) {
			super(detailMessage);
		}

		public HttpException(String detailMessage, Throwable throwable) {
			super(detailMessage, throwable);
		}

		public HttpException(Throwable throwable) {
			super(throwable);
		}

	}
	
	public static class ParseException extends Exception {

		private static final long serialVersionUID = 3132128578218204998L;

		public ParseException() {
			super();
		}

		public ParseException(String detailMessage) {
			super(detailMessage);
		}

		public ParseException(String detailMessage, Throwable throwable) {
			super(detailMessage, throwable);
		}

		public ParseException(Throwable throwable) {
			super(throwable);
		}

	}
}
