package com.example.weibotest;

import java.io.Serializable;
import java.util.Date;


public class MBlog implements Serializable {
	private static final long serialVersionUID = -3514924369786543050L;
	public String uid;
	public String favid;
	public String mblogid;
	public String nick;
	public String portrait;
	public boolean vip;
	public String content;
	public String rtrootuid;
	public String rtrootid;
	public String rtrootnick;
	public boolean rtrootvip;
	public String rtreason;
	public int rtnum;
	public int commentnum;
	public Date time;
	public String pic;
	public String src;
	public String longitude;// ����
	public String latitude;// γ��

	public boolean equals(Object o) {
		if (o == null) return false;
		if (o == this) return true;
		Class<?> cla = o.getClass();
		if (cla == getClass()) {
			MBlog other = (MBlog) o;
			if (other.mblogid.equals(mblogid)) return true;
		}
		return false;
	}

	public int hashCode() {
		return mblogid.hashCode() * 101 >> 12;
	}


}
