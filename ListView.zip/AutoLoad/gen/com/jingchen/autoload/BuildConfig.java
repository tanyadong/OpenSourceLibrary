/** Automatically generated file. DO NOT MODIFY */
package com.jingchen.autoload;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}