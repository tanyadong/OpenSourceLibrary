package com.jerry.newsList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jerry.entity.News;
import com.jerry.parser.NewsConnector;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;

public class AsyncTaskDemo extends Activity implements OnScrollListener {

	private ListView mListView;
	LinearLayout loadingLayout;
	private ListViewAdapter adapter;

	private int startIndex = 1;// �ӵ�1����ʼ
	private int size = 10;// ÿ������ʮ������
	private List<News> newsList;
	List<Map<String, String>> data ;

	/*
	 * ���ò�����ʾ����
	 */
	private LayoutParams mLayoutParams = new LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);

	private LayoutParams ffLayoutParams = new LayoutParams(
			LinearLayout.LayoutParams.FILL_PARENT,
			LinearLayout.LayoutParams.FILL_PARENT);

	private ProgressBar progressBar;
	private boolean isloading;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.news_main);
		data=new ArrayList<Map<String, String>>();
		addView();
	}
	
	private void addView() {
		if (startIndex == 1) {
			newsList = new ArrayList<News>();
			newsList = getNewsList();
		}
		getdata(newsList);
		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.HORIZONTAL);
		progressBar = new ProgressBar(this);
		layout.addView(progressBar, mLayoutParams);
		TextView textView = new TextView(this);
		textView.setText("������...");
		textView.setGravity(Gravity.CENTER_VERTICAL);
		layout.addView(textView, ffLayoutParams);
		layout.setGravity(Gravity.CENTER);
		loadingLayout = new LinearLayout(this);
		loadingLayout.addView(layout, mLayoutParams);
		loadingLayout.setGravity(Gravity.CENTER);

		// �õ�һ��ListView������ʾ��Ŀ
		mListView = (ListView) findViewById(R.id.listView);
		mListView.addFooterView(loadingLayout);
		adapter = new ListViewAdapter();
		mListView.setAdapter(adapter);
		mListView.setOnScrollListener(this);
		mListView.setTextFilterEnabled(true);
	}
	
	class ListViewAdapter extends BaseAdapter {
		int count = 10;

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return count;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			convertView = LayoutInflater.from(getApplicationContext()).inflate(
					R.layout.news_item, null);
			TextView textView = (TextView) convertView
					.findViewById(R.id.textNewsTitle);
			textView.setText((data.get(position)).get("title"));
			return convertView;
		}
	}
	
	private List<Map<String, String>> getdata(List<News> list) {

		if (list == null)
			return null;
		for (News news : list) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("title", news.getTitle());
			data.add(map);
		}
		return data;
	}
	
	/*
	 * ��ȡ�������� ע�����Ƿ��ʱ�����һ�����ŷ���ʹ��asp.net������ʵ�ֵģ���һ��ʱ���Ҵ���дһ��ϵ�����ܽ����Ŀ
	 * �������Ŀ��һ������android����Ѷ��������
	 */
	private List<News> getNewsList() {
		String path = "http://10.0.2.2/getNewsList.aspx";
		String xmlStr = "<?xml version='1.0' encoding='utf-8'?><source><categoryIds>1,3,7</categoryIds><startIndex>"
				+ startIndex
				+ "</startIndex><detail>2</detail><count>"
				+ size
				+ "</count></source>";
		NewsConnector newsConnector = new NewsConnector();
		List<News> list = new ArrayList<News>();
		list = newsConnector.getNewsList(path, xmlStr);
		return list;
	}

	@Override
	public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		if(arg1+arg2==arg3)
		{
			if(!isloading)
			{
				new myAsyncTask().execute(null);
			}
			else
			{
				mListView.removeFooterView(loadingLayout);
			}
		}
	}

	@Override
	public void onScrollStateChanged(AbsListView arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}
	
	private class myAsyncTask extends AsyncTask<Void, Void, Void>
	{

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			newsList = new ArrayList<News>();
			newsList = getNewsList();
			getdata(newsList);
			return null;
			
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			adapter.count+=size;
			adapter.notifyDataSetChanged();
			startIndex+=size;
			isloading=false;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			isloading=true;
		}
		
	}

}
