package com.jerry.newsList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class mainActivity extends Activity implements OnClickListener {
	private Button btnHandler;
	private Button btnAsyncTask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		btnAsyncTask=(Button)findViewById(R.id.btnHandler);
		btnHandler=(Button)findViewById(R.id.btnAsyncTask);
		
		btnAsyncTask.setOnClickListener(this);
		btnHandler.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btnHandler:
			Intent intent1=new Intent(this,HandlerDemo.class);
		    startActivity(intent1);
			break;
		case R.id.btnAsyncTask:
			Intent intent2=new Intent(this,AsyncTaskDemo.class);
		    startActivity(intent2);
			break;

		default:
			break;
		}
	}

}
