package com.jerry.parser;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.jerry.entity.News;


public class NewsHandler extends DefaultHandler {

	final int NEWSID=0x0001;
	final int NEWSTITLE=0x0002;
	final int NEWSSOURCE=0x0004;
	
	int currentState=0;
	News news;
	
	List<News> list;
	
	public List<News> getNewsList()
	{
		return list;
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		// TODO Auto-generated method stub
	//	super.characters(ch, start, length);
		String theString=String.valueOf(ch, start, length);
		switch (currentState) {
		case NEWSID:
			news.setId(theString);
			currentState=0;
			break;
		case NEWSTITLE:
			news.setTitle(theString);
			currentState=0;
			break;
		case NEWSSOURCE:
			news.setNewsSource(theString);
			currentState=0;
			break;
			
		default:
			break;
		}
	}

	@Override
	public void endDocument() throws SAXException {
		// TODO Auto-generated method stub
		super.endDocument();
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		// TODO Auto-generated method stub
		//super.endElement(uri, localName, qName);
		if(localName.equals("news"))
		{
			list.add(news);
		}
		
	}

	@Override
	public void startDocument() throws SAXException {
		// TODO Auto-generated method stub
		list=new ArrayList<News>();
		//super.startDocument();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		// TODO Auto-generated method stub
	//	super.startElement(uri, localName, qName, attributes);
		
		if(localName.equals("news"))
		{
			news=new News();
		    currentState=0;
		    return;
		}
		else if(localName.equals("newsId"))
		{
			currentState=NEWSID;
			return;
		}
		else if(localName.equals("newsTitle"))
		{
			currentState=NEWSTITLE;
			return;
		}
		else if(localName.equals("newsSource"))
		{
			currentState=NEWSSOURCE;
			return;
		}
		else
		{
			currentState=0;
			return;
		}
	}
	
	
	
}
