package com.jerry.parser;

import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.jerry.entity.News;


public class NewsConnector {

	public List<News> getNewsList(String path, String postData) {
		try {
			URL url = new URL(path);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestProperty("Pragma:", "no-cache");
			conn.setRequestProperty("Cache-Control", "no-cache");
			conn.setRequestProperty("Content-Type", "text/xml");
			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(postData);
			out.flush();
			out.close();
			SAXParserFactory factory=SAXParserFactory.newInstance();
			SAXParser parser=factory.newSAXParser();
			XMLReader reader=parser.getXMLReader();
			NewsHandler handler=new NewsHandler();
			reader.setContentHandler(handler);
			reader.parse(new InputSource(conn.getInputStream()));
			return handler.getNewsList();

		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
