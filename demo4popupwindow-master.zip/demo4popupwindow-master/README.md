带有黑色半透明背景的popupwindow从ActionBar下方滑出实现

效果图如下：
![image](https://github.com/lololiu/demo4popupwindow/raw/master/screenshots/screenshot.gif)

