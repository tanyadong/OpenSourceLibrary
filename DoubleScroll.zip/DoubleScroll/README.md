# ysnowsSlidingMenu
仿QQ侧滑菜单效果

知识点: 自定义viewgroup,以及自定义属性的应用.
        动画的定义和应用
