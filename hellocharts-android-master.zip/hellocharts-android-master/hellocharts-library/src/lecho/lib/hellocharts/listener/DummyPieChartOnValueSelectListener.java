package lecho.lib.hellocharts.listener;


import lecho.lib.hellocharts.model.SliceValue;

public class DummyPieChartOnValueSelectListener implements PieChartOnValueSelectListener {

    @Override
    public void onValueSelected(int arcIndex, SliceValue value) {

    }

    @Override
    public void onValueDeselected() {

    }
}
