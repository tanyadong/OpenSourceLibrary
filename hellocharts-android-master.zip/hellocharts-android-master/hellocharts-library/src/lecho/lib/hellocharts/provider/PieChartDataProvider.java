package lecho.lib.hellocharts.provider;

import lecho.lib.hellocharts.model.PieChartData;

public interface PieChartDataProvider {

    public PieChartData getPieChartData();

    public void setPieChartData(PieChartData data);

}
