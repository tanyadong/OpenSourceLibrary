package com.example.getcsdnlistview;

public class BlogListInfo {
	private String  blogTitle;//���ı���
	private String  blogUrl;//���ĵ�ַ
	private String  blogSummary;//����ժҪ
	private String  blogTime;//���ķ���ʱ��
	private String  blogReply;//���Ļظ���
	private String  blogReadNum;//���������

	public String getBlogTitle() {
		return blogTitle;
	}
	public void setBlogTitle(String blogTitle) {
		this.blogTitle = blogTitle;
	}
	public String getBlogUrl() {
		return blogUrl;
	}
	public void setBlogUrl(String blogUrl) {
		this.blogUrl = blogUrl;
	}
	public String getBlogSummary() {
		return blogSummary;
	}
	public void setBlogSummary(String blogSummary) {
		this.blogSummary = blogSummary;
	}
	public String getBlogTime() {
		return blogTime;
	}
	public void setBlogTime(String blogTime) {
		this.blogTime = blogTime;
	}
	public String getBlogReply() {
		return blogReply;
	}
	public void setBlogReply(String blogReply) {
		this.blogReply = blogReply;
	}
	public String getBlogReadNum() {
		return blogReadNum;
	}
	public void setBlogReadNum(String blogReadNum) {
		this.blogReadNum = blogReadNum;
	}
}
