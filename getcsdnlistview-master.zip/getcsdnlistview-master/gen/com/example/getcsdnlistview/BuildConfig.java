/** Automatically generated file. DO NOT MODIFY */
package com.example.getcsdnlistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}