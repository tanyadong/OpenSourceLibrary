# HearthstoneCards
A simple Android app shows Hearthstone cards with okhttp, retrofit, dagger2 and Meterail Design
![](2016_03_07_11_14_02_178.gif)