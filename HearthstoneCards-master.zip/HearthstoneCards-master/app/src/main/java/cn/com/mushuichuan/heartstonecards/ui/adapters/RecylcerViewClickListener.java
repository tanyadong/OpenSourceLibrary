package cn.com.mushuichuan.heartstonecards.ui.adapters;

import android.view.View;

/**
 * Created by Liyanshun on 2016/2/23.
 */
public interface RecylcerViewClickListener {
    void onClick(View v, int poistion);
}
