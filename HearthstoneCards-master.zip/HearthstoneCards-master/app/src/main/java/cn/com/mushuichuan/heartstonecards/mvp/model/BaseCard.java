package cn.com.mushuichuan.heartstonecards.mvp.model;

/**
 * Created by Liyanshun on 2016/2/19.
 */
public class BaseCard {
    public String cardId;
    public String name;
    public String img;
    public String locale;
}
