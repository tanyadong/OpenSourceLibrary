package com.example.mylistview;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


public class MyAdapter extends BaseAdapter{
	
	List<Map<String,String>> list;
	
	Context context;
	
	public MyAdapter(Context context,List list){
		this.context = context;
		this.list = list;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder viewHolder = new ViewHolder();
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.list, null);
			viewHolder.id = (TextView) convertView.findViewById(R.id.id);
			viewHolder.name = (TextView) convertView.findViewById(R.id.name);
			viewHolder.phone = (TextView) convertView.findViewById(R.id.phone);
			convertView.setTag(viewHolder);
		}else{
			viewHolder = (ViewHolder)convertView.getTag();
		}
		// 设置应用名称
		Map<String,String> map = list.get(position);
		viewHolder.id.setText(map.get("id"));
		viewHolder.name.setText(map.get("name"));
		viewHolder.phone.setText(map.get("phone"));
		return convertView;		
	}
	
	private static class ViewHolder { 
        public TextView id,name,phone; 
    } 
}