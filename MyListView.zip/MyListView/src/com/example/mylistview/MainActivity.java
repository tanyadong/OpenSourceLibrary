package com.example.mylistview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity implements OnScrollListener{

	ListView listView;
	List<Map<String,String>> list = new ArrayList();
	MyAdapter adapter;
	//底部footer
	View footer;
	//最大页数
	int maxPage = 5;
	//当前页数
	int page = 1;
	//每页显示数
	int pageSize = 20;
	//是否加载数据中
	boolean isLoading = false;
	//Toast显示状态
	boolean isToast = false;
	
	Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			if(msg.what == 1){
				//得到消息中的数据
				list.addAll((List)msg.obj);
				//告诉适配器，数据变化了，从新加载listview
				adapter.notifyDataSetChanged();
				//移除底部footer
				listView.removeFooterView(footer);
				//当前页数增加
				page++;
				//设置加载中为false
				isLoading = false;
			}else if(msg.what == 0){
				//设置加载中为false
				isToast = false;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		listView = (ListView)findViewById(R.id.lv);
		list = DataService.getData(pageSize, page);
		adapter = new MyAdapter(this, list);
		listView.setAdapter(adapter);
		footer = LayoutInflater.from(this).inflate(R.layout.footer, null);
		listView.setOnScrollListener(this);
	}
	/**
	 * 滚动条状态，1是滑动，0是静止
	 */
	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// TODO Auto-generated method stub
//		if(SCROLL_STATE_TOUCH_SCROLL == scrollState){
//			System.out.println("SCROLL_STATE_TOUCH_SCROLL  "+scrollState );
//		}else if(SCROLL_STATE_IDLE == scrollState){
//			System.out.println("SCROLL_STATE_IDLE  "+scrollState );
//		}
	}
	/**
	 * 监听移动滚动条
	 */
	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		// 如果正在加载，就return，防止加载多次
		if(isLoading)
			return;
		// 得到listview中显示在界面底部的id
		int lastItemid = listView.getLastVisiblePosition();
		// 如果是listview中显示在界面底部的id=滚动条中Item总数，说明滑动到底部了，并且当前页<=总页数
		if((lastItemid+1) == totalItemCount && page <= maxPage){
			if(page == maxPage){//到最后一页，提示（此方法有bug，会提示多次,，加个线程会好一点，但是还不能完全解决）
				if(!isToast){
					isToast = true;
					Toast.makeText(this, "没有更多的数据了...", 0).show();
					new Thread(){
						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								Thread.sleep(3000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							handler.sendMessage(handler.obtainMessage(0, null));
						}
					}.start();
				}
				return;
			}
			//设置正在加载中
			isLoading = true;
			if(totalItemCount > 0){
				//现在底部footer
				listView.addFooterView(footer);
				new Thread(){
					@Override
					public void run() {
						// TODO Auto-generated method stub
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						List list  = DataService.getData(pageSize, page+1);
						handler.sendMessage(handler.obtainMessage(1, list));
					}
				}.start();
			}
		}
		//System.out.println("firstVisibleItem:"+firstVisibleItem+" visibleItemCount:"+visibleItemCount+" totalItemCount:"+totalItemCount);
	}
}
