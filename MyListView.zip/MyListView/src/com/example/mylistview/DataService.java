package com.example.mylistview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataService {

	public static List<Map<String,String>> getData(int pageSize,int page){
		List<Map<String,String>> list = new ArrayList();
		int index = (pageSize*(page-1)+1);
		int max = pageSize * page;
		for(int i = index; i <= max; i++){
			Map<String,String> map = new HashMap();
			map.put("id", "ID:"+i);
			map.put("name", "姓名:"+i);
			map.put("phone", "电话:"+i);
			list.add(map);
		}
		return list;
	}
}
