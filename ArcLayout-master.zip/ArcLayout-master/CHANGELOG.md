# Version 1.1.0

* Bump up android support library version to 22.2.1

# Version 1.0.1

* Fix a bug that NullPointerException occurs during preview #3

# Version 1.0.0

Initial release.
