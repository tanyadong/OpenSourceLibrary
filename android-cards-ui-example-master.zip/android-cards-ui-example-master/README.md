Android Cards UI Example
========================

A simple implementation of Cards UI using ListView and Adapter logic.
