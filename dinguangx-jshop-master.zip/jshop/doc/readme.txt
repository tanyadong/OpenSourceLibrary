项目配置：
1、导入doc/jeeshop.sql文件到数据库
2、修改conf.properties中有关数据库用户名密码的配置。
3、项目启动方式为maven方式，即使用maven命令：mvn tomcat6:run
4、本地访问方式：
后台管理页面
http://127.0.0.1:8080/jshop/manage/user/login
后台账号
	admin/123456	管理员账号，拥有全部权限
门户测试账号：test1/123456


-------------------------------------------------------------------
项目主页：http://git.oschina.net/dinguangx/jshop
项目文档：http://git.oschina.net/dinguangx/jshop/wikis/home
有疑问或寻求帮助可以联系jshop交流讨论群：417059832

免责申明：用户可免费使用本软件，但与此造成的任何问题本与本作者无关。