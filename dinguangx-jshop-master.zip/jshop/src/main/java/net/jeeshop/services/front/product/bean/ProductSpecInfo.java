package net.jeeshop.services.front.product.bean;

public class ProductSpecInfo {
	private String id;
//	private 
}
