package net.jeeshop.services.front.news.bean;

import java.io.Serializable;


public class News extends net.jeeshop.services.common.News implements Serializable {
	
	@Override
	public void clear() {
		super.clear();
	}

}
