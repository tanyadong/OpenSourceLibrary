package net.jeeshop.core.util;

/**
 * 省市区工具类
 * @author huangf
 *
 */
public class AreaHelper {
	
}
